
import { Component, OnInit } from '@angular/core';  
import { FormBuilder, Validators } from '@angular/forms';  
import { Observable } from 'rxjs';  
import {StudentService } from '../student.service';  
import { Student } from '../studentModule';  
  
@Component({  
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'] 
})  
export class StudentComponent implements OnInit {  
  dataSaved = false;  
  studentForm: any;  
  allStudents:  any;  
 studentIdUpdate = null;  
  massage = null;  
  public studentDetails:Student[];
  //public studentDetails:any[];
  colorPriorityDetails : Student[];
  constructor(private formbulider: FormBuilder, private studentService:StudentService) { }  
  
  ngOnInit() {  
    this.studentForm = this.formbulider.group({  
      StudentName: ['', [Validators.required]],  
      EmailId: ['', [Validators.required]] 
        });  
    this.loadAllStudents();  
  }  
  loadAllStudents() {  
    this.allStudents = this.studentService.getAllStudent().subscribe(result =>{this.studentDetails = result as Student[]
      }); //console.log(this.studentDetails);
     
  }  
  onFormSubmit() {  
    this.dataSaved = false;  
    const student = this.studentForm.value;  
    this.CreateStudent(student);  
    this.studentForm.reset();  
  }  
  loadStudentToEdit(studentId: any) {  
    this.studentService.getStudentById(studentId).subscribe(student=> {  
      this.massage = null;  
      this.dataSaved = false;  
      this.studentIdUpdate = student.data.id;  
      this.studentForm.controls['StudentName'].setValue(student.data.first_name);  
      this.studentForm.controls['EmailId'].setValue(student.data.email);  
    });  
  
  }  
  CreateStudent(student: Student) {  
    if (this.studentIdUpdate == null) {  
      this.studentService.createStudent(student).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.massage = 'Record saved Successfully';  
          this.loadAllStudents();  
          this.studentIdUpdate= null;  
          this.studentForm.reset();  
        }  
      );  
    } else {  
      student.Id = this.studentIdUpdate;  
      this.studentService.updateStudent(student).subscribe(() => {  
        this.dataSaved = true;  
        this.massage = 'Record Updated Successfully';  
        this.loadAllStudents();  
        this.studentIdUpdate = null;  
        this.studentForm.reset();  
      });  
    }  
  }   
  deleteStudent(studentId: any) {  
    if (confirm("Are you sure you want to delete this ?")) {   
    this.studentService.deleteStudentById(studentId).subscribe(() => {  
      this.dataSaved = true;  
      this.massage = 'Record Deleted Succefully';  
      this.loadAllStudents();  
      this.studentIdUpdate = null;  
      this.studentForm.reset();  
  
    });  
  }  
}  
  resetForm() {  
    this.studentForm.reset();  
    this.massage = null;  
    this.dataSaved = false;  
  }  
}  

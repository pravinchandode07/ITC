export class Student {  
    Id: Int32Array;  
    email:string;
    first_name: string; 
    last_name: string;  
    avatar:ImageBitmap;  
}  
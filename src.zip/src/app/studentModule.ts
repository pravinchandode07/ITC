export class Student {  
    Id: any;  
    email:string;
    first_name: string; 
    last_name: string;  
    avatar:ImageBitmap;  
}  
import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable} from 'rxjs';  
//import {map} from 'rxjs/add/operator/map';
import { map} from 'rxjs/operators';
//import { tap,catchError} from 'rxjs/operators';
import { Student } from './studentModule'; 
@Injectable({
  providedIn: 'root'

})
export class StudentService {  
    url = 'https://reqres.in/';  
    constructor(private http: HttpClient) { }  
    getAllStudent(): 
     // return this.http.get(this.url + 'api/users?page=2');
      //return this.http.get(this.url + 'api/users?page=2').pipe(map(data => {})).subscribe(result => {console.log(result);});
    Observable<Student[]> {  
      return this.http.get<Student[]>(this.url + 'api/users?page=2');
    
    }  
    getStudentById(studentId: any): Observable<Student> {  
      return this.http.get<Student>(this.url + 'api/users/' + studentId);  
    } 
    createStudent(student: Student): Observable<Student> {  
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
      return this.http.post<Student>(this.url + 'api/users/',  
      student, httpOptions);  
    }  
    updateStudent(student: Student): Observable<Student> {  
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
      return this.http.put<Student>(this.url + 'api/users/2',  
      student, httpOptions);  
    }  
    deleteStudentById(studentId: Int32Array): Observable<number> {  
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
      return this.http.delete<number>(this.url + 'api/users/' +studentId,  
   httpOptions);  
    }  
  }  